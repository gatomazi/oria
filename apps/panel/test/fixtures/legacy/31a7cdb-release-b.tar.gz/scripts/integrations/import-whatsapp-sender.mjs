#!/usr/bin/env node
// Fase 5b · importa o remetente WhatsApp que hoje mora no ambiente do whatsapp-webhook-go para a
// integração `whatsapp` de UMA Organization (OPS-29).
//
//   META_PHONE_NUMBER_ID (Go) → WHATSAPP_LEGACY_PHONE_NUMBER_ID → integrations.config.phone_number_id
//   META_WABA_ID         (Go) → WHATSAPP_LEGACY_WABA_ID         → integrations.config.waba_id
//   META_ACCESS_TOKEN    (Go) → WHATSAPP_LEGACY_ACCESS_TOKEN    → integration_secrets (access_token)
//
// O número do ambiente do Go não diz de quem é: a instalação tem um só, e escolher "a Organization
// que existir" é exatamente o que a Fase 5b remove. Por isso a Organization é argumento obrigatório,
// escolhido pelo operador — e o número é reivindicado para ela (PD-016): se outra Organization já o
// tem, o import falha.
//
// Segredo nenhum aparece em argumento, log ou saída: os valores vêm só do ambiente, e o relatório
// traz o resultado e o last4. Idempotente.
//
// Uso (role de migration, no pre-deploy — nunca o processo da app):
//   DATABASE_URL=... ENCRYPTION_MASTER_KEY=... WHATSAPP_LEGACY_PHONE_NUMBER_ID=... \
//   WHATSAPP_LEGACY_WABA_ID=... WHATSAPP_LEGACY_ACCESS_TOKEN=... \
//     node scripts/integrations/import-whatsapp-sender.mjs --organization <uuid>            (simula)
//   ... node scripts/integrations/import-whatsapp-sender.mjs --organization <uuid> --aplicar
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const pg = require('pg');
const { createKeyring } = require('../../lib/secrets/keyring.js');
const { createSecretStore } = require('../../lib/secrets/store.js');
const { SEGREDOS } = require('../../lib/platform/integrations.js');
const { validarConfiguracao } = require('../../lib/platform/whatsapp-sender.js');

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const CONTEXTO = SEGREDOS.whatsapp.access_token;

export async function importarRemetenteWhatsapp(url, { env = process.env, organizationId, aplicar = false } = {}) {
  if (!organizationId || !UUID_RE.test(organizationId)) throw new Error('informe --organization <uuid> (a Organization dona do número)');
  const org = organizationId.toLowerCase();
  const phoneNumberId = String(env.WHATSAPP_LEGACY_PHONE_NUMBER_ID || '').trim();
  const wabaId = String(env.WHATSAPP_LEGACY_WABA_ID || '').trim();
  const accessToken = String(env.WHATSAPP_LEGACY_ACCESS_TOKEN || '').trim();
  const invalido = validarConfiguracao({ phoneNumberId, wabaId, accessToken });
  if (invalido) throw new Error(`WHATSAPP_LEGACY_*: ${invalido}`);

  const keyring = createKeyring(env);
  if (aplicar && !keyring.disponivel()) throw new Error('ENCRYPTION_MASTER_KEY ausente — não há como gravar o token');
  const client = new pg.Client({ connectionString: url });
  await client.connect();
  const store = createSecretStore({ pool: { query: (...a) => client.query(...a) }, keyring });
  const relatorio = { aplicado: aplicar, organizationId: org, phoneNumberId, wabaId, last4: accessToken.slice(-4), resultado: null };
  try {
    const { rows: ativas } = await client.query(
      'SELECT organization_id FROM tenancy_organizations_para_jobs() WHERE organization_id = $1', [org]
    );
    if (!ativas.length) throw new Error(`organization ${org} não existe ou não está ativa`);

    await client.query('BEGIN');
    try {
      await client.query("SELECT set_config('app.current_organization_id', $1, true)", [org]);
      const { rows: [dono] } = await client.query(
        `SELECT organization_id FROM external_resource_claims WHERE provider = 'whatsapp' AND tipo = 'phone_number' AND external_id = $1`,
        [phoneNumberId]
      );
      if (dono && dono.organization_id !== org) throw new Error('este número já pertence a outra organization');

      const { rows: [integ] } = await client.query(
        `SELECT id, config FROM integrations WHERE organization_id = $1 AND provider = 'whatsapp' AND escopo IS NULL`, [org]
      );
      const configIgual = integ && integ.config && integ.config.phone_number_id === phoneNumberId && integ.config.waba_id === wabaId;
      const tokenIgual = integ && await store.usarSegredo(
        { integrationId: integ.id, organizationId: org, tipo: 'access_token', contexto: CONTEXTO, aceitarVencido: true },
        (atual) => atual === accessToken
      ).catch(() => false);
      if (configIgual && tokenIgual && dono) {
        relatorio.resultado = 'ja_importado';
      } else if (integ && integ.config && integ.config.phone_number_id && integ.config.phone_number_id !== phoneNumberId) {
        // Não sobrescreve um número que o owner já cadastrou na tela.
        throw new Error('a organization já tem outro número cadastrado — confira antes de importar');
      } else if (!aplicar) {
        relatorio.resultado = 'a_importar';
      } else {
        const { rows: [claim] } = await client.query(
          "SELECT integracao_reivindicar_recurso('whatsapp', 'phone_number', $1) AS ok", [phoneNumberId]
        );
        if (!claim.ok) throw new Error('este número já pertence a outra organization');
        await client.query(
          `INSERT INTO integrations (organization_id, provider, escopo, status) VALUES ($1, 'whatsapp', NULL, 'disconnected')
           ON CONFLICT DO NOTHING`,
          [org]
        );
        const { rows: [nova] } = await client.query(
          `SELECT id FROM integrations WHERE organization_id = $1 AND provider = 'whatsapp' AND escopo IS NULL`, [org]
        );
        await client.query(
          `UPDATE integrations SET config = $1::jsonb, atualizado_em = now() WHERE id = $2 AND organization_id = $3`,
          [JSON.stringify({ phone_number_id: phoneNumberId, waba_id: wabaId }), nova.id, org]
        );
        if (!tokenIgual) {
          await store.gravar({ integrationId: nova.id, organizationId: org, tipo: 'access_token', valor: accessToken, expiresAt: null, contexto: CONTEXTO });
        }
        const ok = await store.usarSegredo(
          { integrationId: nova.id, organizationId: org, tipo: 'access_token', contexto: CONTEXTO },
          (lido) => lido === accessToken
        );
        if (!ok) throw new Error('verificação do token gravado falhou');
        await client.query(`UPDATE integrations SET status = 'connected', atualizado_em = now() WHERE id = $1 AND organization_id = $2`, [nova.id, org]);
        relatorio.resultado = 'importado';
      }
      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK').catch(() => {});
      throw err;
    }
  } finally {
    await client.end();
  }
  return relatorio;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  if (!process.env.DATABASE_URL) {
    console.error('DATABASE_URL ausente');
    process.exit(2);
  }
  const args = process.argv.slice(2);
  const i = args.indexOf('--organization');
  importarRemetenteWhatsapp(process.env.DATABASE_URL, {
    organizationId: i >= 0 ? args[i + 1] : null,
    aplicar: args.includes('--aplicar'),
  })
    .then((r) => {
      console.log(`whatsapp: organization ${r.organizationId} ← número ${r.phoneNumberId}, WABA ${r.wabaId}, token final ${r.last4}: ${r.resultado}${r.aplicado ? '' : ' — SIMULAÇÃO (use --aplicar)'}`);
    })
    .catch((err) => { console.error(`whatsapp: ${err.message}`); process.exit(1); });
}
