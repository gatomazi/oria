#!/usr/bin/env node
// Seed EXPLÍCITO de entitlements por Organization — OPS-21 (TD-012 V1).
//
//   ENTITLEMENTS_SEED_ORGANIZATION_IDS   Organizations (vírgula). Nada é deduzido: sem id, nada acontece.
//   ENTITLEMENTS_SEED_FEATURES           features a LIGAR (vírgula), do vocabulário fechado de
//                                        lib/platform/entitlements.js. Feature desconhecida = erro.
//
// Liga só o que foi listado; não desliga nada, não inventa default. Feature não listada continua
// ausente do plano — e ausência nega. Idempotente. Sem nenhuma das variáveis: não faz nada (exit 0).
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const pg = require('pg');
const { FEATURES } = require('../../lib/platform/entitlements.js');

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const lista = (v) => String(v || '').split(',').map((x) => x.trim()).filter(Boolean);

export async function seedEntitlements(url, env = process.env) {
  const orgs = lista(env.ENTITLEMENTS_SEED_ORGANIZATION_IDS);
  const features = lista(env.ENTITLEMENTS_SEED_FEATURES);
  if (!orgs.length && !features.length) return { feito: false, motivo: 'sem configuração de seed' };
  if (!orgs.length) throw new Error('seed de entitlements incompleto: falta ENTITLEMENTS_SEED_ORGANIZATION_IDS');
  if (!features.length) throw new Error('seed de entitlements incompleto: falta ENTITLEMENTS_SEED_FEATURES');
  const invalidas = orgs.filter((o) => !UUID_RE.test(o));
  if (invalidas.length) throw new Error(`ENTITLEMENTS_SEED_ORGANIZATION_IDS com id inválido: ${invalidas.join(', ')}`);
  const desconhecidas = features.filter((f) => !FEATURES.includes(f));
  if (desconhecidas.length) throw new Error(`feature fora do vocabulário: ${desconhecidas.join(', ')}`);

  const client = new pg.Client({ connectionString: url });
  await client.connect();
  try {
    await client.query('BEGIN');
    for (const org of orgs) {
      await client.query("SELECT set_config('app.current_organization_id', $1, true)", [org]);
      const { rows } = await client.query('SELECT 1 FROM organizations WHERE id = $1', [org]);
      if (!rows.length) throw new Error(`Organization inexistente: ${org}`);
      const ligar = JSON.stringify(Object.fromEntries(features.map((f) => [f, true])));
      await client.query(
        `INSERT INTO app_config (organization_id, chave, valor, atualizado_em)
         VALUES ($1, 'entitlements', $2::jsonb, now())
         ON CONFLICT (organization_id, chave) DO UPDATE
           SET valor = (CASE WHEN jsonb_typeof(app_config.valor) = 'object' THEN app_config.valor ELSE '{}'::jsonb END) || EXCLUDED.valor,
               atualizado_em = now()`,
        [org, ligar]
      );
    }
    await client.query('COMMIT');
    return { feito: true, organizations: orgs, features };
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    await client.end();
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  if (!process.env.DATABASE_URL) {
    console.error('DATABASE_URL ausente');
    process.exit(2);
  }
  seedEntitlements(process.env.DATABASE_URL)
    .then((r) => console.log(r.feito
      ? `entitlements: ${r.features.join(', ')} ligadas em ${r.organizations.length} organization(s)`
      : `entitlements: nada a fazer (${r.motivo})`))
    .catch((err) => { console.error(`entitlements: ${err.message}`); process.exit(1); });
}
