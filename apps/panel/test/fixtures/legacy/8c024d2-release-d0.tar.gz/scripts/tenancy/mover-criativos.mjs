#!/usr/bin/env node
// Move os arquivos do Gerador de Criativos do tenant legado da instalação para a Organization dona
// (Fase 3 · INV-22, OPS-22). A migration 1789800000000 já trocou tenant_id pelo id da Organization no
// banco; os arquivos em UPLOADS_DIR/creatives/tenant/<legado>/ precisam acompanhar.
//
// Uso: node scripts/tenancy/mover-criativos.mjs --uploads <UPLOADS_DIR> --de <legado> --para <organization_id> [--aplicar]
// Sem --aplicar só mostra o que faria. Nunca sobrescreve: destino existente = erro.
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const { TENANT_RE } = require('../../lib/creative-core/storage.js');
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

export function planejarMovimento({ uploads, de, para }) {
  if (!uploads) throw new Error('--uploads obrigatório');
  if (!TENANT_RE.test(String(de || ''))) throw new Error('--de inválido');
  if (!UUID_RE.test(String(para || ''))) throw new Error('--para precisa ser o id (uuid minúsculo) da Organization');
  const raiz = path.resolve(uploads, 'creatives', 'tenant');
  const origem = path.join(raiz, de);
  const destino = path.join(raiz, para);
  if (!fs.existsSync(origem)) return { origem, destino, acao: 'nada', motivo: 'origem inexistente' };
  if (fs.existsSync(destino)) throw new Error(`destino já existe: ${destino} — mova à mão, conferindo o conteúdo`);
  return { origem, destino, acao: 'mover' };
}

export function moverCriativos(opcoes, { aplicar = false } = {}) {
  const plano = planejarMovimento(opcoes);
  if (plano.acao === 'mover' && aplicar) fs.renameSync(plano.origem, plano.destino);
  return { ...plano, aplicado: plano.acao === 'mover' && aplicar };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const args = process.argv.slice(2);
  const valor = (nome) => { const i = args.indexOf(nome); return i === -1 ? undefined : args[i + 1]; };
  try {
    const r = moverCriativos(
      { uploads: valor('--uploads'), de: valor('--de'), para: valor('--para') },
      { aplicar: args.includes('--aplicar') }
    );
    if (r.acao === 'nada') console.log(`criativos: nada a mover (${r.motivo})`);
    else console.log(`criativos: ${r.origem} → ${r.destino}${r.aplicado ? '' : ' (simulação; use --aplicar)'}`);
  } catch (err) {
    console.error(`criativos: ${err.message}`);
    process.exit(1);
  }
}
