// Fase 6 · Tenant #1 — arquivo de mapeamento, argumentos, conexão e saída.
//
// Nada aqui escolhe cenário, Organization ou dono. O operador declara tudo num arquivo (versão 1):
//
//   {
//     "versao": 1,
//     "cenario": "A" | "B",                        // PD-019: tem que bater com --scenario
//     "mapeamentoTenancy": "cenario-a.json",       // formato de lib/platform/tenancy-mapping.js
//     "creativeTenantLegado": "default",           // pasta antiga do Creative Core
//     "organizations": [{ "id": "<uuid>", "entitlements": ["financial", ...] }],
//     "owners": [{ "email": "...", "passwordHashEnv": "NOME_DA_VARIAVEL", "organizations": ["<uuid>"] }],
//     "whatsapp": null | { "organizationId": "<uuid>" },
//     "inkWebhook": null | { "organizations": ["<uuid>"] }
//   }
//
// `whatsapp` e `inkWebhook` são obrigatórios como CHAVE: `null` é a declaração explícita de "não faz
// parte desta execução" (PD-019 e a obrigatoriedade de WhatsApp/Ink seguem com o usuário). Ausência
// da chave é erro — nada é inferido.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const tm = require('../../lib/platform/tenancy-mapping.js');
const { LOJAS_LEGADAS } = require('../../lib/platform/tenancy-manifest.js');
const { FEATURES } = require('../../lib/platform/entitlements.js');

export const RAIZ = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
export const CENARIOS = Object.freeze(['A', 'B']);

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+$/;
const ENV_RE = /^[A-Z][A-Z0-9_]{2,80}$/;
const TENANT_LEGADO_RE = /^[a-z0-9_-]{1,64}$/;
const CHAVES = ['versao', 'cenario', 'mapeamentoTenancy', 'creativeTenantLegado', 'organizations', 'owners', 'whatsapp', 'inkWebhook'];

export class Tenant1Error extends Error {
  constructor(message, detalhes = []) {
    super(detalhes.length ? `${message}\n  - ${detalhes.join('\n  - ')}` : message);
    this.name = 'Tenant1Error';
    this.detalhes = detalhes;
  }
}

const listaDeIds = (v) => Array.isArray(v) && v.length > 0 && v.every((x) => typeof x === 'string' && UUID_RE.test(x));

// PD-019: a forma do mapeamento precisa ser a do cenário DECLARADO. Não há "parece B".
export function conferirCenario(cenario, mapeamento) {
  const erros = [];
  const orgs = mapeamento.organizations;
  const donoDaLoja = new Map(mapeamento.mapeamentos.filter((m) => m.tipo === 'loja').map((m) => [m.chave, m.organizationId]));
  if (cenario === 'A') {
    if (orgs.length !== LOJAS_LEGADAS.length) erros.push(`cenário A exige ${LOJAS_LEGADAS.length} Organizations (recebi ${orgs.length})`);
    const lojas = orgs.map((o) => o.store.lojaLegada);
    for (const l of LOJAS_LEGADAS) {
      if (lojas.filter((x) => x === l).length !== 1) erros.push(`cenário A: a loja legada "${l}" precisa ser a Store de exatamente uma Organization`);
    }
    const donos = LOJAS_LEGADAS.map((l) => donoDaLoja.get(l));
    if (new Set(donos).size !== LOJAS_LEGADAS.length) erros.push('cenário A: cada loja legada precisa de uma Organization própria');
  } else if (cenario === 'B') {
    if (orgs.length !== 1) erros.push(`cenário B exige 1 Organization (recebi ${orgs.length})`);
    // Confere a declaração de cada Organization do arquivo; nada é atribuído "à única".
    for (const o of orgs) {
      if (!LOJAS_LEGADAS.includes(o.store.lojaLegada)) erros.push('cenário B: a Store precisa declarar a loja legada que ela assume (lojaLegada)');
      for (const l of LOJAS_LEGADAS) {
        if (donoDaLoja.get(l) !== o.id) erros.push(`cenário B: loja:${l} precisa convergir explicitamente para ${o.id}`);
      }
    }
  } else {
    erros.push(`cenário desconhecido: ${JSON.stringify(cenario)}`);
  }
  return erros;
}

export function validarTenant1(json, { dir, cenario }) {
  const erros = [];
  if (!json || typeof json !== 'object' || Array.isArray(json)) throw new Tenant1Error('arquivo de Tenant #1 precisa ser um objeto JSON');
  const extras = Object.keys(json).filter((k) => !CHAVES.includes(k));
  if (extras.length) erros.push(`campos não aceitos: ${extras.join(', ')}`);
  const faltando = CHAVES.filter((k) => !Object.prototype.hasOwnProperty.call(json, k));
  if (faltando.length) erros.push(`campos obrigatórios ausentes (use null para "não se aplica"): ${faltando.join(', ')}`);
  if (json.versao !== 1) erros.push(`versao ${JSON.stringify(json.versao)} não suportada (esperado 1)`);
  if (!CENARIOS.includes(json.cenario)) erros.push(`cenario precisa ser "A" ou "B" (recebi ${JSON.stringify(json.cenario)})`);
  if (cenario !== json.cenario) erros.push(`--scenario ${cenario} não confere com o cenario do arquivo (${JSON.stringify(json.cenario)})`);
  if (typeof json.creativeTenantLegado !== 'string' || !TENANT_LEGADO_RE.test(json.creativeTenantLegado)) {
    erros.push('creativeTenantLegado inválido');
  }
  if (erros.length) throw new Tenant1Error('arquivo de Tenant #1 inválido', erros);

  let mapeamento;
  const arquivoMapeamento = typeof json.mapeamentoTenancy === 'string' ? path.resolve(dir, json.mapeamentoTenancy) : null;
  if (!arquivoMapeamento) throw new Tenant1Error('arquivo de Tenant #1 inválido', ['mapeamentoTenancy ausente']);
  try {
    mapeamento = tm.lerMapeamentoDeArquivo(arquivoMapeamento);
    tm.verificarCompletudeRuntime(mapeamento, { creativeTenant: json.creativeTenantLegado });
  } catch (err) {
    throw new Tenant1Error('mapeamento de tenancy inválido', [err.message]);
  }
  erros.push(...conferirCenario(json.cenario, mapeamento));

  const idsMapeamento = new Set(mapeamento.organizations.map((o) => o.id));
  const organizations = [];
  if (!Array.isArray(json.organizations)) erros.push('organizations precisa ser uma lista');
  else {
    const vistos = new Set();
    for (const [i, o] of json.organizations.entries()) {
      const onde = `organizations[${i}]`;
      const extra = Object.keys(o || {}).filter((k) => !['id', 'entitlements'].includes(k));
      if (extra.length) erros.push(`${onde}: campos não aceitos: ${extra.join(', ')}`);
      if (!o || !UUID_RE.test(o.id || '')) { erros.push(`${onde}.id não é UUID minúsculo`); continue; }
      if (!idsMapeamento.has(o.id)) erros.push(`${onde}.id ${o.id} não está no mapeamento de tenancy`);
      if (vistos.has(o.id)) erros.push(`${onde}.id duplicado — ambíguo`);
      vistos.add(o.id);
      if (!Array.isArray(o.entitlements) || !o.entitlements.every((f) => typeof f === 'string')) {
        erros.push(`${onde}.entitlements precisa ser uma lista (vazia = nenhuma feature)`);
        continue;
      }
      const desconhecidas = o.entitlements.filter((f) => !FEATURES.includes(f));
      if (desconhecidas.length) erros.push(`${onde}.entitlements fora do vocabulário: ${desconhecidas.join(', ')}`);
      if (new Set(o.entitlements).size !== o.entitlements.length) erros.push(`${onde}.entitlements com repetição`);
      organizations.push({ id: o.id, entitlements: [...o.entitlements].sort() });
    }
    for (const id of idsMapeamento) if (!vistos.has(id)) erros.push(`Organization ${id} do mapeamento sem entrada em organizations`);
  }

  const owners = [];
  if (!Array.isArray(json.owners) || !json.owners.length) erros.push('owners precisa ser uma lista não vazia');
  else {
    const emails = new Set();
    const cobertas = new Set();
    for (const [i, o] of json.owners.entries()) {
      const onde = `owners[${i}]`;
      const extra = Object.keys(o || {}).filter((k) => !['email', 'passwordHashEnv', 'organizations'].includes(k));
      if (extra.length) erros.push(`${onde}: campos não aceitos: ${extra.join(', ')}`);
      const email = String((o && o.email) || '').trim().toLowerCase();
      if (!EMAIL_RE.test(email)) erros.push(`${onde}.email inválido`);
      if (emails.has(email)) erros.push(`${onde}.email repetido — ambíguo`);
      emails.add(email);
      if (!ENV_RE.test(String((o && o.passwordHashEnv) || ''))) erros.push(`${onde}.passwordHashEnv precisa ser o NOME de uma variável de ambiente`);
      if (!listaDeIds(o && o.organizations)) { erros.push(`${onde}.organizations precisa listar UUIDs`); continue; }
      if (new Set(o.organizations).size !== o.organizations.length) erros.push(`${onde}.organizations com repetição`);
      for (const id of o.organizations) {
        if (!idsMapeamento.has(id)) erros.push(`${onde}: Organization ${id} fora do mapeamento`);
        cobertas.add(id);
      }
      owners.push({ email, passwordHashEnv: o.passwordHashEnv, organizations: [...o.organizations].sort() });
    }
    for (const id of idsMapeamento) if (!cobertas.has(id)) erros.push(`Organization ${id} sem owner declarado`);
  }

  let whatsapp = null;
  if (json.whatsapp !== null && json.whatsapp !== undefined) {
    const extra = Object.keys(json.whatsapp).filter((k) => k !== 'organizationId');
    if (extra.length) erros.push(`whatsapp: campos não aceitos: ${extra.join(', ')}`);
    if (!idsMapeamento.has(json.whatsapp.organizationId)) erros.push('whatsapp.organizationId precisa ser uma Organization do mapeamento');
    else whatsapp = { organizationId: json.whatsapp.organizationId };
  }

  let inkWebhook = null;
  if (json.inkWebhook !== null && json.inkWebhook !== undefined) {
    const extra = Object.keys(json.inkWebhook).filter((k) => k !== 'organizations');
    if (extra.length) erros.push(`inkWebhook: campos não aceitos: ${extra.join(', ')}`);
    if (!listaDeIds(json.inkWebhook.organizations)) erros.push('inkWebhook.organizations precisa listar UUIDs');
    else {
      const fora = json.inkWebhook.organizations.filter((id) => !idsMapeamento.has(id));
      if (fora.length) erros.push(`inkWebhook: Organization fora do mapeamento: ${fora.join(', ')}`);
      if (new Set(json.inkWebhook.organizations).size !== json.inkWebhook.organizations.length) erros.push('inkWebhook.organizations com repetição');
      inkWebhook = { organizations: [...json.inkWebhook.organizations].sort() };
    }
  }

  if (erros.length) throw new Tenant1Error('arquivo de Tenant #1 inválido', erros);

  const porId = new Map(mapeamento.organizations.map((o) => [o.id, o]));
  return {
    versao: 1,
    cenario: json.cenario,
    arquivoMapeamento,
    mapeamento,
    creativeTenantLegado: json.creativeTenantLegado,
    organizations: organizations
      .map((o) => ({ ...o, nome: porId.get(o.id).nome, store: porId.get(o.id).store }))
      .sort((a, b) => a.id.localeCompare(b.id)),
    owners,
    whatsapp,
    inkWebhook,
    // Dono declarado do Creative Core legado.
    donoCriativos: mapeamento.mapeamentos.find((m) => m.tipo === 'creative_tenant' && m.chave === json.creativeTenantLegado).organizationId,
  };
}

export function lerTenant1(caminho, { cenario }) {
  let bruto;
  try {
    bruto = fs.readFileSync(caminho, 'utf8');
  } catch (err) {
    throw new Tenant1Error(`não foi possível ler o arquivo de Tenant #1 (${err.code || err.message})`);
  }
  let json;
  try {
    json = JSON.parse(bruto);
  } catch (err) {
    throw new Tenant1Error(`arquivo de Tenant #1 não é JSON válido: ${err.message}`);
  }
  return validarTenant1(json, { dir: path.dirname(path.resolve(caminho)), cenario });
}

// ── argumentos ─────────────────────────────────────────────────────────────────────────────────
const OPCOES = Object.freeze({
  '--scenario': 'valor',
  '--mapping': 'valor',
  '--uploads': 'valor',
  '--app-role': 'valor',
  '--saida-segredos': 'valor',
  '--snapshot': 'valor',
  '--aplicar': 'flag',
});

export function lerArgs(argv) {
  const r = { aplicar: false };
  for (let i = 0; i < argv.length; i += 1) {
    const a = argv[i];
    if (!OPCOES[a]) throw new Tenant1Error(`argumento desconhecido: ${a}`);
    if (OPCOES[a] === 'flag') { r.aplicar = true; continue; }
    const v = argv[i + 1];
    if (v === undefined || v.startsWith('--')) throw new Tenant1Error(`${a} exige um valor`);
    r[a.slice(2).replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = v;
    i += 1;
  }
  return r;
}

// Cenário e arquivo são obrigatórios em todos os comandos: sem eles, FAIL — nunca inferência.
export function exigirCenarioEArquivo(args) {
  const erros = [];
  if (!args.scenario) erros.push('--scenario A|B não informado — o cenário de PD-019 nunca é inferido');
  else if (!CENARIOS.includes(args.scenario)) erros.push(`--scenario precisa ser A ou B (recebi ${args.scenario})`);
  if (!args.mapping) erros.push('--mapping <arquivo> não informado — o dono dos dados nunca é inferido');
  if (erros.length) throw new Tenant1Error('execução recusada', erros);
  return lerTenant1(args.mapping, { cenario: args.scenario });
}

// ── conexão ────────────────────────────────────────────────────────────────────────────────────
// Leitura: a sessão inteira é READ ONLY no servidor — preflight, plan e verify não conseguem gravar
// nem por engano (inclusive nos imports em modo simulação que eles chamam).
export function urlSomenteLeitura(url) {
  const u = new URL(url);
  u.searchParams.set('options', '-c default_transaction_read_only=on');
  return u.toString();
}

const HOSTS_LOCAIS = new Set(['localhost', '127.0.0.1', '[::1]', '::1']);

// apply e rollback: só banco local/teste nesta fase. Produção fica para o rollout, com runbook.
export function exigirBancoLocal(url, env = process.env) {
  const erros = [];
  let host = '';
  try {
    host = new URL(url).hostname;
  } catch {
    erros.push('DATABASE_URL inválida');
  }
  if (host && !HOSTS_LOCAIS.has(host)) erros.push(`host ${host} não é local — apply/rollback só rodam contra banco local ou de teste`);
  if (String(env.NODE_ENV || '').toLowerCase() === 'production') erros.push('NODE_ENV=production — recusado');
  const railway = Object.keys(env).filter((k) => k.startsWith('RAILWAY_'));
  if (railway.length) erros.push('ambiente Railway detectado — recusado');
  if (erros.length) throw new Tenant1Error('banco não permitido para escrita', erros);
}

// ── saída ──────────────────────────────────────────────────────────────────────────────────────
const NOME_SENSIVEL = /(SECRET|TOKEN|PASSWORD|PASSWD|MASTER_KEY|_HASH|API_KEY|RESOLVER_KEY|ACCESS_KEY)/;

function valoresSensiveis(env) {
  const valores = [];
  for (const [k, v] of Object.entries(env)) {
    if (typeof v !== 'string' || v.length < 8) continue;
    if (NOME_SENSIVEL.test(k)) valores.push(v);
  }
  for (const k of ['DATABASE_URL', 'TEST_DATABASE_URL']) {
    try {
      const u = new URL(env[k] || '');
      if (u.password && u.password.length >= 4) valores.push(decodeURIComponent(u.password));
    } catch { /* sem URL */ }
  }
  return valores;
}

// Toda linha sai por aqui. Se algum valor sensível do ambiente aparecer, ele é trocado e a execução
// é marcada como vazamento (exit ≠ 0) — um segredo no stdout é bug, não detalhe.
export function criarSaida({ env = process.env, escrever = (l) => process.stdout.write(`${l}\n`) } = {}) {
  const sensiveis = valoresSensiveis(env);
  const estado = { vazou: false, linhas: [] };
  function linha(texto) {
    let t = String(texto);
    for (const v of sensiveis) {
      if (t.includes(v)) { t = t.split(v).join('[REDACTED]'); estado.vazou = true; }
    }
    t = t.replace(/(postgres(?:ql)?:\/\/[^:\s/]+:)[^@\s]+@/g, '$1[REDACTED]@');
    estado.linhas.push(t);
    escrever(t);
  }
  return { linha, estado };
}

export function imprimirItens(saida, itens) {
  for (const it of itens) saida.linha(`${it.status.padEnd(4)} ${it.id}${it.detalhe ? ` — ${it.detalhe}` : ''}`);
}

export function resultado(itens) {
  return itens.some((i) => i.status === 'FAIL') ? 'FAIL' : 'PASS';
}
